import pyttsx3 # pip install pyttsx3
# import speech_recognition as sr #pip install speechRecognition
import datetime
import wikipedia # pip install wikipedia
import webbrowser
import os
import random
import time
from tkinter import *
from PIL import  ImageTk, Image # pip install pillow
# import pyaudio
# import wave
import pickle
# from sklearn.neural_network import MLPClassifier
from tkinter import messagebox
from googlesearch import search # pip install google-search
from youtube_search import YoutubeSearch #pip install youtube-search
from threading import *
import serial
# import pyautogui
from tkinter import ttk

## my modules
from utils import extract_feature
from SpeechRecognitionToWav import SpeechRecognition
from collapsing_frame import CollapsingFrame as CF
from animated_background import ImageLabel


try:
    arduino_on = serial.Serial('COM5', 9600)
except:
    pass

def start_decission_thread(var):
    # E.set()
    global new_thread
    new_thread = Thread(target=decission_making,args=(var))
    new_thread.daemon = True
    new_thread.start()

engine = pyttsx3.init() # sapi5
voices = engine.getProperty("voices")
#print(voices)
engine.setProperty("voice",voices[0].id)

def reset_all():
    text_val.set("")
    delete_user()
    delete_Brain_Stromer()


def speech_recognition_decission():
    audio_file = SpeechRecognition()
    dspvalue.set("Listening . . .")
    Display.update()
    audio = audio_file.recognize_speech_To_wav()
    dspvalue.set("Recognizing . . .")
    Display.update()
    return audio


def speech_emotion():
    try:
        # load the saved model (after training)
        model = pickle.load(open("result/mlp_classifier-2.model", "rb"))
        print("Please talk . . . ")
        filename = "test.wav"
        # record the file (start talking)
        # record_to_file(filename)
        # extract features and reshape it
        features = extract_feature(filename, mfcc=True, chroma=True, mel=True).reshape(1, -1)
        # predict
        result = model.predict(features)[0]
        # show the result !
        print("result:", result)
        return result
    except:
        messagebox.showwarning("Brain Stormer","Please Turn Off or Turn On Emotion Detection in order to proceed!!")
        

def Brain_Stromer_interface(a,b):
    lbx_Brain_Stromer.insert(a,b)

def user_interface(a,b):
    lbx_user.insert(a,b)
    text_val.set(b)
    # text_input.set(a) #

def speek(audio):
    engine.say(audio)
    engine.runAndWait()

def wishMe():
    hour = int(datetime.datetime.now().hour)
    if hour>=0 and hour<12:
        speek("Good Morning")
    elif hour>=12 and hour<18:
        speek("Good Afternoon")
    else:
        speek("Good Evening")
    speek("I am Brain Stormer, sir. Please tell me how may I help you.")


def takeCommand():
        #It takes microphone input from the user and returns string output
        global emo
        emo = "0"
        query = speech_recognition_decission()
        print("take command ",query)
        # print(emo,emo_enable)
        emo_list=["neutral","calm","happy","sad","angry","fearful","disgust","surprised"]
        emo_stat = emovalue.get() in emo_list
        if emovalue.get() == "Emotion Detection Turned On" or emo_stat:
            emo = speech_emotion()
            emovalue.set(emo)
            emo_Display.update()
        print("Listening....")
        time.sleep(1)
        try:
            print("Recognizing...")
            print(f"User Said:'{query}'\n")
            if query == "google speech recognition could not understand audio":
                Brain_Stromer_interface(0,"Sorry! I unable to recognise you.")
                lbx_Brain_Stromer.update()
                dspvalue.set("Done ")
                Display.update()
                # speek("google speech recognition could not understand audio")
                return query
            if query == "please turn on your internet connection":
                Brain_Stromer_interface(0,"please turn on your internet connection")
                lbx_Brain_Stromer.update()
                dspvalue.set("Done ")
                Display.update()
                # speek("google speech recognition could not understand audio")
                return query
            user_interface(0,query)
            dspvalue.set("Done ")
            Display.update()
        except Exception as e:
            # print(e)
            print("Say that again please . . . . . . .")
            dspvalue.set("Did not recognise")
            Display.update()
            speek("I did not recognize you. Please say again")
            return "none"
        return query


def decission_making(var):
    # global query
    global text_input
    # text_input_type = str(type(text_input))
    a = var[0]
    print(a)
    if a == "t":
        query = text_input.get()
        emovalue.set("Emotion Detection Turned off")
    elif a == "v":
        query=takeCommand().lower()
        print(query)
        #logic for execution tasks based on query
        # print(emo)
    print(query)
    query_list = query.split(" ")
    count=0

    if query == "google speech recognition could not understand audio":
        speek("Sorry! I unable to recognise you.")
        count=1
        # return 0

    elif query == "please turn on your internet connection":
        speek("please turn on your internet connection")
        return 0

    greet_list = ["hi","hello","hey","hai"]
    for i in greet_list:
        if i in query_list:
            Brain_Stromer_interface(0,"Hello")
            lbx_Brain_Stromer.update()
            speek("hello")
            count = 1
    if count ==0:
        wiki_count=0
        list_identity=["who are you","your name","make you","about yourself","made you","how are you"]
        wh_list=["what","who","how","which","whose","whom","where","when","why","do you know"] # what
        for i in wh_list:
            for j in list_identity:
                if j in query:
                    if "how are you" in j:
                        Brain_Stromer_interface(0,"I am fine.")
                        lbx_Brain_Stromer.update()
                        speek("I am fine.")
                        count=1
                    if "who are you" in j:
                        Brain_Stromer_interface(0,"I am Brain Stormer")
                        lbx_Brain_Stromer.update()
                        speek("I am Brain Stormer")
                        count=1
                    elif "your name" in j:
                        Brain_Stromer_interface(0,"My Name is Brain Stormer")
                        lbx_Brain_Stromer.update()
                        speek("My Name is Brain Stormer")
                        count=1
                    elif "make you" in j:
                        Brain_Stromer_interface(0,"Team Tech Blaster made me")
                        lbx_Brain_Stromer.update()
                        speek("Team Tech Blaster made me")
                        count=1
                    elif "made you" in j:
                        Brain_Stromer_interface(0,"Team Tech Blaster made me")
                        lbx_Brain_Stromer.update()
                        speek("Team Tech Blaster made me")
                        count=1
                    elif "about yourself" in j:
                        Brain_Stromer_interface(0,"I am Brain Stormer. I am an AI assistant system. I have inbuilt disease prediction system. I have ability to open web browser, youtube, play music or song and much more things. This AI system is made by Team Tech Blaster.")
                        lbx_Brain_Stromer.update()
                        speek("I am Brain Stormer. I am an AI assistant system. I have inbuilt disease prediction system. I have ability to open web browser, youtube, play music or song and much more things. I can detect Humans emotion. This AI system is made by Team Tech Blaster.")
                        count=1
                    wiki_count=1
                    break

            if wiki_count==0:
                if i in query_list:
                    speek("Searching your answer, please wait..... ")
                    # query = query.replace("wikipedia","")
                    try:
                        results = wikipedia.summary(query,sentences=1)
                        Brain_Stromer_interface(0,results)
                        lbx_Brain_Stromer.update()
                        speek("Your answer is")
                        print(results)
                        speek(results)
                        count=1
                    except:
                        try:
                            for k in search(query, tld="co.in", num=5, stop=1, pause=2):
                                print(k)
                            Brain_Stromer_interface(0,"I am opening a web page to get best answer of your query.")
                            lbx_Brain_Stromer.update()
                            speek("I am opening a web page to get best answer of your query")
                            webbrowser.open(k)
                            count=1
                        except:
                            Brain_Stromer_interface(0,"Sorry, Unable to find any result")
                            lbx_Brain_Stromer.update()
                            speek("Sorry, Unable to find any result")
                            count=1
            break

    

    if "open youtube" in query:
        webbrowser.open("https://www.youtube.com/")
        Brain_Stromer_interface(0,"YouTube Opened in your default Web Browser")
        lbx_Brain_Stromer.update()
        speek("YouTube Opened in your default Web Browser")
        count=1


    elif "open google" in query:
        webbrowser.open("https://www.google.co.in/")
        Brain_Stromer_interface(0,"Google Opened in your default Web Browser")
        lbx_Brain_Stromer.update()
        speek("Google Opened in your default Web Browser")
        count=1

    list_song = ["play music","play song","play a music","play a song","play the song","play the music","song","music"]
    for i in list_song:
        if i in query_list:
            if emovalue.get() == emo:
                if emo == "happy" or emo=="calm":
                    speek(f"You are looking {emo}. I am going to play some music related to your {emo}ness")
                    youtube_songs_results = YoutubeSearch(f'{emo} songs', max_results=5).to_dict()
                    music_no = random.randint(0,4)
                    youtube_url_suffix = youtube_songs_results[music_no]["url_suffix"]
                    try:
                        url_songs = "https://www.youtube.com/"+ youtube_url_suffix
                        print(url_songs)
                        webbrowser.open(url_songs)
                    except:
                        messagebox.showwarning("System","Sorry...I did not get anything...")


                elif emo == "angry" or emo =="disgust":
                    speek(f"You are looking {emo}.Please calm down for a bit. I am going to play some interesting music.")
                    youtube_songs_results = YoutubeSearch(f'songs to overcome stress', max_results=5).to_dict()
                    music_no = random.randint(0,4)
                    youtube_url_suffix = youtube_songs_results[music_no]["url_suffix"]
                    try:
                        url_songs = "https://www.youtube.com/"+ youtube_url_suffix
                        print(url_songs)
                        webbrowser.open(url_songs)
                    except:
                        messagebox.showwarning("System","Sorry...I did not get anything...")
                else:
                    speek("I am going to play some music")
                    webbrowser.open("https://www.youtube.com/results?search_query=songs")

            else:
                #music_dir = "F:\college events\IEM Hakathons\disease prediction modified\songs for Brain_Stromer"
                songs = YoutubeSearch(query, max_results=5).to_dict()
                # music_no = random.randint(0,4)
                youtube_url_suffix = songs[0]["url_suffix"]
                print(songs)
                Brain_Stromer_interface(0,f"I am going to play your song")
                lbx_Brain_Stromer.update()
                speek(f"I am going to play your song")
                #os.startfile(os.path.join(music_dir,songs[music_no]))
                try:
                    url_songs = "https://www.youtube.com/"+ youtube_url_suffix
                    print(url_songs)
                    webbrowser.open(url_songs)
                except:
                    messagebox.showwarning("System","Sorry...I did not get anything...")
            count=1
            break

    # j=0
    list_time=["present time","current time","now time","time"]
    for i in list_time:
        if count == 1:
            break
        if i in query_list:
            strTime = datetime.datetime.now().strftime("%H:%M:%S")
            print(strTime)
            Brain_Stromer_interface(0,f"sir, the time is: {strTime}")
            lbx_Brain_Stromer.update()
            speek(f"sir, the time is: {strTime}")
            count=1
            break

    list_pay=["pay","payment","fee","fees","bill"]
    for i in list_pay:
        if count==1:
            break
        elif i in query_list:
            # print("****")
            if "phonepe" in query:
                Brain_Stromer_interface(0,f"I am going to open home page of phonepe. You please continue your payment procedure.")
                lbx_Brain_Stromer.update()
                speek("I am going to open home page of phonepay. You please continue your payment procedure.")
                webbrowser.open("https://www.phonepe.com/")
                count=1
                # j=1
                break
            g_pay_list = ["g-pay","gpay","googlepay","google pay"]
            for k in g_pay_list:
                if k in query:
                    Brain_Stromer_interface(0,f"I am going to open home page of {k}. You please continue your payment procedure.")
                    lbx_Brain_Stromer.update()
                    speek(f"I am going to open home page of google pay. You please continue your payment procedure.")
                    webbrowser.open("https://pay.google.com/")
                    count=1
                    # j=1
                    break
            if "paytm" in query:
                Brain_Stromer_interface(0,f"I am going to open home page of paytm. You please continue your payment procedure.")
                lbx_Brain_Stromer.update()
                speek("I am going to open home page of pay tm. You please continue your payment procedure.")
                webbrowser.open("https://paytm.com/")
                count=1
                # j=1
                break


    list_ill = ["ill","uneasy","feeling not good"]
    for i in list_ill:
        if count == 1:
            break
        if i in query_list:
            # j=1
            Brain_Stromer_interface(0,f"Don't worry! You will recover very soon.")
            lbx_Brain_Stromer.update()
            speek("Don't worry! You will recover very soon.")
            Brain_Stromer_interface(0,f"I am Opening disease predictor")
            lbx_Brain_Stromer.update()
            disease_pred()
            count=1
            break

    list_wrong = ["wrong", "incorrect"]
    
    for i in list_wrong:
        if count == 1:
            break
        if i in query_list:
            Brain_Stromer_interface(0,"Sorry sir, next time I will try to increase my accuracy")
            lbx_Brain_Stromer.update()
            speek("Sorry sir, next time I will try to increase my accuracy")
            # j=1
            count=1
            break

    list_correct = ["good","nice","fine","awesome","perfect","correct","thank you"]
    for i in list_correct:
        if count == 1:
            break
        elif i in query_list:
            print("Thank you")
            Brain_Stromer_interface(0,"Thank you, sir")
            lbx_Brain_Stromer.update()
            speek("Thank you, sir")
            count=1
            break

    list_exit=["exit","quit","close","stop"]
    for i in list_exit:
        if count == 1:
            break
        if i in query_list:
            Brain_Stromer_interface(0,"Bye for now. Thank you for using me.")
            lbx_Brain_Stromer.update()
            speek("Bye for now. Thank you for using me.")

            
            root.destroy()
            

# ~~~~~~~~~~~~ Home Automation ~~~~~~~~~~~~~~~~~  
    try:
        list_light = ["led", "light", "bulb"]
        if "on" in query_list:
            
            if "all" in query_list:
                speek("I am turning on all appliances")
                time.sleep(1) 
                arduino_on.write('3'.encode())
                time.sleep(1) 
                arduino_on.write('2'.encode())
                count = 1
            else:
                for i in list_light:
                    if i in query_list:
                        speek(f"I am turning on {i}")
                        time.sleep(1) 
                        arduino_on.write('3'.encode())  # arduino_on.write('3'.encode())
                        count=1
                if "fan" in query_list:
                    speek("I am turning on fan")
                    time.sleep(1) 
                    arduino_on.write('2'.encode())
                    count = 1
            time.sleep(1) ##### wait for initializing

        if "off" in query_list:
            # arduino_off = serial.Serial('COM5', 9600) 
            if "all" in query_list:
                speek("I am turning off all appliances")
                time.sleep(1) 
                arduino_on.write('0'.encode())
                time.sleep(1) 
                arduino_on.write('1'.encode())
                count = 1
            else:
                for i in list_light:
                    if i in query_list:
                        speek(f"I am turning off {i}")
                        time.sleep(1) 
                        arduino_on.write('0'.encode()) #arduino_on.write('0'.encode())
                        count=1
                if "fan" in query_list:
                    speek("I am turning off fan")
                    time.sleep(1) 
                    arduino_on.write('1'.encode())
                    count = 1
            time.sleep(1) ##### wait for initializing
    except:
        speek("Please Connect your Lifi Module")
        count = 1

    if count==0:
        if dspvalue.get()!="Did not recognise":
            try:
                for k in search(query, tld="co.in", num=5, stop=1, pause=2):
                    print(k)
                Brain_Stromer_interface(0,"I am opening a web page to get best answer of your query.")
                lbx_Brain_Stromer.update()
                speek("I am opening a web page to get best answer of your query")
                webbrowser.open(k)
            except:
                print(dspvalue.get())
                print("query",query)
                print("count",count)
                Brain_Stromer_interface(0,"Sorry, I Don't Know Proper Answer of Your Question")
                lbx_Brain_Stromer.update()
                speek("Sorry, I Don't Know Proper Answer of Your Question")
    global chk
    if chk.get()==1:
        decission_making("v")
        

root=Tk()
# root.wm_attributes('-alpha', 0.95)
Set_width = 1376
Set_height = 750
root.geometry(f"{Set_width}x{Set_height}+70+20")
root.minsize(1200,750) 
# root.maxsize(500,700)
root.configure(bg="cyan")
# icon = PhotoImage(file = "images/brain_logo.ico")
root.title("~ ~ Brain Stormer ~ ~\n AI Assistant System")
print("~ ~ ~ ~ ~ Welcome to Brain Stormer AI Assistant System ~ ~ ~ ~ ~ ")


lbl = ImageLabel(root)
lbl.place(x=0,y=0)
lbl.load('images/animated_background.gif')

######~~~~~~~~~~~~~~~ Menu Bar ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 
# Creating Menubar
menubar = Menu(root,bd=10,relief="ridge")
  
# Adding File Menu and commands
file = Menu(menubar, tearoff = 0,bd=10,relief="ridge")
menubar.add_cascade(label ='File', menu = file)
file.add_command(label ='Reset', command =  reset_all)
file.add_command(label ='Exit', command = root.destroy)


# Adding Help Menu
help_ = Menu(menubar, tearoff = 0)
menubar.add_cascade(label ='Help', menu = help_)
# help_.add_command(label ='Tk Help', command = None)
help_.add_command(label ='User Manual', command = None)
help_.add_separator()
help_.add_command(label ='About us', command = None)
# display Menu
root.config(menu = menubar)
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

###########~~~~~~~~~~~~~~~~ Collapsing Window ~~~~~~~~~~~~~~~~~~~~
def mouse_hover(button,color_on_hover,color_on_leave):
    button.bind("<Enter>",func=lambda e: button.config(background = color_on_hover))
    button.bind("<Leave>",func=lambda e: button.config(background = color_on_leave))

nav_bar = Frame(root)
cf = CF(nav_bar)
cf.pack(fill='x',anchor="nw")
# option group 1
group1 = ttk.Frame(cf, padding=5)
# for x in range(1):
    # ttk.Checkbutton(group1, text=f'Option {x + 1}').pack(fill='x')

send_img = Image.open("images/send.png") 
send_image = send_img.resize((35,35),Image.ANTIALIAS)
send_image = ImageTk.PhotoImage(send_image)

global text_val
text_val = StringVar()
text_val.set("")
text_input = Entry(group1,text='type here',textvariable = text_val,font = ("times",18),bg="#DAF2FF",fg="#25004D") #groove, raised, ridge, solid, or sunken
send_btn = Button(group1,image = send_image,bg ="#FDFFE4",cursor="hand2",relief = "raised",bd = 5,command=lambda: start_decission_thread("t")) #,text="submit",compound=LEFT
send_btn.pack(side="right")
text_input.pack(fill='x',ipady = 5,)
cf.add(group1) # style='primary.TButton'
nav_bar.pack(fill="x",side="bottom")

mouse_hover(send_btn,"#CDE0CB","#FDFFE4")

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#Setting logo
image = Image.open("images/Brain_Stromer_logo.png") 
image = image.resize((100,100),Image.ANTIALIAS)
image=ImageTk.PhotoImage(image)
Label(root,image=image).pack(ipady=5,ipadx=5)
#Setting top text
f_top = Frame(root,bg="cyan")
Label(f_top,text="Welcome to Brain Stormer AI Assistant System", font="times 20 bold",padx=10,pady=5,fg="purple4",bg="alice blue").pack(fill=X)
f_top.pack(pady=10)


# Intermediate msg display screen
dspvalue=StringVar()
dspvalue.set("")
f1=Frame(root,relief=SUNKEN)
Label(f1,text="Brain Stormer Status",font="times 15 bold italic").pack(side=LEFT)
Display=Entry(f1,textvariable = dspvalue,font="times 20 bold",bg="mint cream",fg="navy")
Display.pack(ipadx=15,ipady=5,pady=5,padx=5,fill=X,side=LEFT)

# Emotion msg display

emovalue=StringVar()
emovalue.set("Emotion Detection Turned Off")
Label(f1,text="User's Emotion\nStatus",font="times 15 bold italic").pack(side=LEFT,padx=(50,0))
emo_Display=Entry(f1,textvariable = emovalue,font="times 16",bg="mint cream",fg="navy",width=40)
emo_Display.pack(ipadx=15,ipady=5,pady=5,padx=5,fill=X,side=LEFT)

f1.pack(pady=10)

def emo_func_on():
    emovalue.set("Emotion Detection Turned On")
    emo_Display.update()

def emo_func_off():
    emovalue.set("Emotion Detection Turned Off")
    emo_Display.update()


#------------User screen-------------------#
def delete_user():
    lbx_user.delete(0,END)
f1 = Frame(root,bg="azure2")
Label(f1,text="USER QUERY",font="times 14 bold",fg="dark blue",relief=RIDGE).pack()
Button(f1,text="CLEAR",font="Bahnschrift 15 bold",bg="ghost white",fg="red4",relief=GROOVE,command=delete_user).pack(side=BOTTOM)
scrollbar_ux = Scrollbar(f1,orient=HORIZONTAL)
scrollbar_ux.pack(side=BOTTOM, fill=X)
lbx_user=Listbox(f1,width=50,height=20,font="times 13")
lbx_user.pack(fill=Y,side=LEFT,anchor=W,padx=20,pady=15)
scrollbar_ux.config(command=lbx_user.xview)
#lbx_user.insert(0,"First")
f1.pack(side=LEFT)
#Scroll bar
scrollbar_uy = Scrollbar(f1)
scrollbar_uy.pack(side=RIGHT, fill=Y)
scrollbar_uy.config(command=lbx_user.yview)

#------------Brain Stormer screen-------------------#
def delete_Brain_Stromer():
    lbx_Brain_Stromer.delete(0,END)

f2 = Frame(root,bg="azure2")
Label(f2,text="BRAIN STORMER ANSWER",font="times 14 bold",fg="dark blue",relief=RIDGE).pack()
Button(f2,text="CLEAR",font="Bahnschrift 15 bold",bg="ghost white",fg="red4",relief=GROOVE,command=delete_Brain_Stromer).pack(side=BOTTOM)
#horizontal scroll bar
scrollbar_jx = Scrollbar(f2,orient=HORIZONTAL)
scrollbar_jx.pack(side=BOTTOM,fill=X)
#Brain_Stromer listbox
lbx_Brain_Stromer=Listbox(f2,width=50,height=20,font="times 13")
lbx_Brain_Stromer.pack(fill=Y,side=LEFT,anchor=W,padx=20,pady=15)
scrollbar_jx.config(command=lbx_Brain_Stromer.xview)
#lbx_Brain_Stromer.insert(END,"First")
f2.pack(side=RIGHT)
#verticle Scroll bar
scrollbar_jy = Scrollbar(f2)
scrollbar_jy.pack(side=RIGHT, fill=Y)
scrollbar_jy.config(command=lbx_Brain_Stromer.yview)
#----------------------------------------------------------------#

f=Frame(root,bg="#001665")
# Button(f,text="Greet me",font="times 15 bold",bg="spring green",fg="midnightblue",command=wishMe).pack()

# ~~~~~~~~~~~~~~~~~~Emotion Button~~~~~~~~~~~~~~~~~~~~

emo_img = Image.open("images/button_emo.png") 
emo_image = emo_img.resize((150,60),Image.ANTIALIAS)
emo_image = ImageTk.PhotoImage(emo_image)

emo_off_img = Image.open("images/button_emo_off.png") 
emo_off_image = emo_off_img.resize((150,60),Image.ANTIALIAS)
emo_off_image = ImageTk.PhotoImage(emo_off_image)

emo_btn_on = Button(f,image=emo_image,font="times 13 bold",bg="spring green",fg="midnightblue",command=emo_func_on,relief="ridge",bd=4) #text = "Emotion recognition\nturn on"
emo_btn_on.pack(side=RIGHT,padx=(5,0))

emo_btn_off = Button(f,image=emo_off_image,font="times 13 bold",bg="#C43204",fg="#FBE1D8",command=emo_func_off,relief="ridge",bd=4)
emo_btn_off.pack(side=LEFT,padx=(0,1))

f.pack()
##~~~~~~~~~~ Disease window switch button ~~~~~~~~~
def disease_pred():
    # Brain_Stromer_interface(0,"I am Opening disease predictor")
    path = "Disease_prediction_system.py"
    speek("I am Opening disease predictor")
    lbx_Brain_Stromer.update()
    os.startfile(path)

f_d=Frame(root)

dise_img = Image.open("images/disease_pred_img.png")
disease_img = dise_img.resize((60, 60), Image.ANTIALIAS)
disease_img = ImageTk.PhotoImage(disease_img)

disease_pred_switch_btn = Button(f_d,image=disease_img,text="Switch to\nDisease Predictor",cursor="hand1",bg="#FFFBD6",compound=BOTTOM,width=100,command=disease_pred,relief="ridge",bd=6) ##FFFBD6
disease_pred_switch_btn.pack()
f_d.pack(pady=20)

#speak Button
def ch_sp_hover(button,color_on_hover,color_on_leave):
    global ask_brain_stormer_img
    global ask_brain_stormer_leave_img
    button.bind("<Enter>",func=lambda e: button.config(image = ask_brain_stormer_leave_img,background = color_on_hover))
    button.bind("<Leave>",func=lambda e: button.config(image = ask_brain_stormer_img, background = color_on_leave))

f3 = Frame(root)
#ask brain stormer btn image
ask_brain_stormer_img1 = Image.open("images/main_button.png")
ask_brain_stormer_img = ask_brain_stormer_img1.resize((300, 120), Image.ANTIALIAS)
ask_brain_stormer_img = ImageTk.PhotoImage(ask_brain_stormer_img)

#ask brain stormer leave btn image
ask_brain_stormer_img2 = Image.open("images/main_button_e.png")
ask_brain_stormer_leave_img = ask_brain_stormer_img2.resize((300, 120), Image.ANTIALIAS)
ask_brain_stormer_leave_img = ImageTk.PhotoImage(ask_brain_stormer_leave_img)

speak_B = Button(f3,image=ask_brain_stormer_img,cursor="hand2",padx=30,font="Bahnschrift 15 bold",bg="blue",command=lambda: start_decission_thread("v"),bd=0)  #decission_making
speak_B.pack()
f3.pack(pady=10)
ch_sp_hover(speak_B,"green","blue")

def check_status(ch):
    global chk

    if chk.get()==1:
        conversation_label.config(text="Conversation Mode On")
        if ch=="l":
            chk.set(0)  
            conversation_label.config(text="Conversation Mode Off") 
        else: 
            pass
    else:
        conversation_label.config(text="Conversation Mode Off")
        if ch=="l":
            chk.set(1)
            conversation_label.config(text="Conversation Mode On")

#conversion mode button
f4=Frame(root,relief="raised",bd=5,bg="#3051EC") #groove, raised, ridge, solid, or sunken
chk=IntVar()
conversation_label=Label(f4,text="Conversation Mode Off",font="times 13 bold",bg="#3051EC",fg="#EAEEFC")
conversation_label.pack(side=RIGHT,pady=3,padx=(0,6),ipadx=(6))
status_conversation="off"
checkbox_button=Checkbutton(f4,variable=chk,onvalue=1,offvalue=0,command=lambda:check_status("h"),bg="#3051EC",relief="groove",bd=4)
checkbox_button.pack(side=LEFT,padx=(3,0)) #,pady=3,padx=(6,0)
# # Button(f4,text="EXIT",font="Bahnschrift 20 bold",bg="gray5",fg="floral white",pady=5,padx=20,command=lambda:os._exit(1)).pack(side=BOTTOM,ipady=10)

conversation_label.bind("<Button-1>",lambda e:check_status("l"))

f4.pack(side=TOP,pady=(0,15))

root.iconbitmap("images/brain_logo.ico")
    
root.mainloop()
