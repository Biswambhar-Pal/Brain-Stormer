import speech_recognition as sr
import numpy as np
import scipy.io.wavfile
import io

class SpeechRecognition:
    stop_listening = None
    recognizer = None
    microphone = None
    

    def __init__(self):
        self.recognizer = sr.Recognizer()
        self.microphone = sr.Microphone()
        # self.extract = extract

    def recognize_speech_To_wav(self):
        speech_to_text = ""
        with sr.Microphone() as source:
            # print("Say something!")
            self.recognizer.adjust_for_ambient_noise(source) # To adjust the background noise
            self.recognizer.non_speaking_duration = 0.9 #
            self.recognizer.pause_threshold = 0.9
            audio = self.recognizer.listen(source, timeout=None) # to listen the sound through mic, and store that into audio variable as "AudioData" object
            # if self.extract == 1:
            wav_binary = audio.get_wav_data() # to convert "Audiodata" object to binary wav form
            rate, data = scipy.io.wavfile.read(io.BytesIO(wav_binary)) # 'rate' variable stores the sampling rate of audio , data variable stores wav audio data 
            scipy.io.wavfile.write("test.wav",rate, data) # to write wav data into a .wav file
            try:
                speech_to_text = self.recognizer.recognize_google(audio,language="en-in")
                # print(speech_to_text)
                return speech_to_text
            except sr.UnknownValueError:
                print("Google speech Recognition could not understand audio")
                return "google speech recognition could not understand audio"
            except sr.RequestError as e:
                print("Could not request results from Googe Voice Recognition service; {0}".format(e))
                return ("please turn on your internet connection")
        