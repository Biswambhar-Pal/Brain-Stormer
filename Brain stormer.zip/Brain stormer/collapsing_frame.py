from tkinter import ttk
from tkinter import *
from webbrowser import BackgroundBrowser
# from ttkbootstrap import Style

class CollapsingFrame(ttk.Frame):
    """
    A collapsible frame widget that opens and closes with a button click.
    """
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.columnconfigure(0, weight=1)
        self.cumulative_rows = 0

        from PIL import  ImageTk, Image
        self.expand_img = Image.open("images/expand.png") 
        self.expand_image = self.expand_img.resize((80,20),Image.ANTIALIAS)
        self.expand_image = ImageTk.PhotoImage(self.expand_image)

        self.collapse_img = Image.open("images/collapse.png") 
        self.collapse_image = self.collapse_img.resize((80,20),Image.ANTIALIAS)
        self.collapse_image = ImageTk.PhotoImage(self.collapse_image)
        

    def add(self, child, title="", style='primary.TButton', **kwargs):
        if child.winfo_class() != 'TFrame':  # must be a frame
            return
        style_color = style.split('.')[0]
        frm = ttk.Frame(self, style=f'{style_color}.TFrame')
        frm.grid(row=self.cumulative_rows, column=0,sticky='ew') #sticky='ew'

        # header toggle button
        btn = ttk.Button(frm, image = self.expand_image,text = "",compound=LEFT, style=style,width=500 ,command=lambda c=child: self._toggle_open_close(child)) #expand_image
        btn.pack(side='left',fill="x")

        # assign toggle button to child so that it's accesible when toggling (need to change image)
        child.btn = btn
        child.grid(row=self.cumulative_rows + 1, column=0, sticky='news')

        # increment the row assignment
        self.cumulative_rows += 2

    def _toggle_open_close(self, child):
        if child.winfo_viewable():
            child.grid_remove()
            child.btn.configure(image = self.collapse_image) #collapse_image
        else: 
            child.grid()
            child.btn.configure(image = self.expand_image) #expand_image

